/* ================================
   FUNCIONES GLOBALES AUXILIARES
   ================================ */

// Scroll suave a la calculadora de edad
function scrollToAge() {
  const section = document.getElementById("edad");
  if (section) {
    section.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

// Limpiar calculadora de edad
function clearAgeCalculator() {
  const birthInput = document.getElementById("birthdate");
  const ageYears = document.getElementById("age-years");
  const ageMonths = document.getElementById("age-months");
  const ageDays = document.getElementById("age-days");
  const ageMessage = document.getElementById("age-message");
  const ageError = document.getElementById("age-error");
  const ageResult = document.getElementById("age-result");

  if (birthInput) birthInput.value = "";
  if (ageYears) ageYears.textContent = "00";
  if (ageMonths) ageMonths.textContent = "00";
  if (ageDays) ageDays.textContent = "00";
  if (ageMessage) ageMessage.textContent = "";
  if (ageError) ageError.classList.add("hidden");
  if (ageResult) ageResult.classList.add("hidden");
}

/* ======================================
   INICIALIZAR TODO CUANDO CARGA LA PÁGINA
   ====================================== */

document.addEventListener("DOMContentLoaded", () => {
  /* ========= CALCULADORA DE EDAD ========= */
  const ageForm = document.getElementById("age-form");
  const birthInput = document.getElementById("birthdate");
  const ageYears = document.getElementById("age-years");
  const ageMonths = document.getElementById("age-months");
  const ageDays = document.getElementById("age-days");
  const ageResult = document.getElementById("age-result");
  const ageMessage = document.getElementById("age-message");
  const ageError = document.getElementById("age-error");

  if (ageForm && birthInput) {
    ageForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const value = birthInput.value;
      if (!value) {
        ageError.textContent = "Selecciona tu fecha de nacimiento 📅";
        ageError.classList.remove("hidden");
        ageResult.classList.add("hidden");
        return;
      }

      const birth = new Date(value);
      const today = new Date();

      if (birth > today) {
        ageError.textContent = "La fecha no puede ser futura ⏳";
        ageError.classList.remove("hidden");
        ageResult.classList.add("hidden");
        return;
      }

      let years = today.getFullYear() - birth.getFullYear();
      let months = today.getMonth() - birth.getMonth();
      let days = today.getDate() - birth.getDate();

      if (days < 0) {
        months -= 1;
        const previousMonth = new Date(
          today.getFullYear(),
          today.getMonth(),
          0
        );
        days += previousMonth.getDate();
      }

      if (months < 0) {
        years -= 1;
        months += 12;
      }

      if (years < 0 || years > 120) {
        ageError.textContent = "Revisa la fecha, algo no cuadra 🤔";
        ageError.classList.remove("hidden");
        ageResult.classList.add("hidden");
        return;
      }

      ageError.classList.add("hidden");
      ageResult.classList.remove("hidden");

      ageYears.textContent = String(years).padStart(2, "0");
      ageMonths.textContent = String(months).padStart(2, "0");
      ageDays.textContent = String(days).padStart(2, "0");

      let msg = "";
      if (years <= 12) {
        msg =
          "Estás en una etapa llena de descubrimientos ✨ Disfruta y juega mucho.";
      } else if (years <= 17) {
        msg =
          "Estás construyendo tu futuro 📚✨ Cada pequeño esfuerzo suma en tu camino.";
      } else if (years <= 29) {
        msg =
          "Tienes una etapa perfecta para explorar, aprender y equivocarte con valentía 🚀.";
      } else if (years <= 44) {
        msg =
          "Estás en un momento fuerte para hacer realidad tus proyectos y cuidar de ti 💼.";
      } else if (years <= 59) {
        msg =
          "Tienes experiencia y energía combinadas 🌟 Eres más capaz de lo que imaginas.";
      } else {
        msg =
          "Tu historia está llena de sabiduría y momentos únicos 🧠🌈 Gracias por llegar hasta aquí.";
      }

      ageMessage.textContent = msg;
    });
  }

  /* ========= OVERLAY INFO (SOBRE / CONTACTO / PRIVACIDAD / TÉRMINOS) ========= */
  const infoOverlay = document.getElementById("info-overlay");
  const infoOverlayTitle = document.getElementById("info-overlay-title");
  const infoOverlayBody = document.getElementById("info-overlay-body");
  const infoOverlayClose = document.querySelector(".info-overlay-close");
  const infoLinks = document.querySelectorAll("[data-info]");

  const infoContent = {
    about: {
      title: "Sobre nosotros",
      body:
        "CalculaTools es un proyecto independiente creado para ofrecer herramientas simples, rápidas y gratuitas que te ayuden a resolver tareas diarias: cálculos, convertidores, textos y más. Nuestro objetivo es brindarte una experiencia clara, ordenada y accesible desde cualquier dispositivo. Trabajamos constantemente en nuevas calculadoras y nuevas funciones.",
    },
    contact: {
      title: "Contacto",
      body:
        "Si tienes sugerencias, comentarios o encontraste un error en alguna herramienta, puedes escribirnos a:\n\ncontacto@calculatools.com\n\nResponderemos lo más pronto posible.",
    },
    privacy: {
      title: "Privacidad",
      body:
        "CalculaTools no recopila información personal identificable. Las calculadoras funcionan directamente en tu dispositivo y los datos que ingresas no se almacenan en ningún servidor. Nuestro objetivo es ofrecer herramientas útiles sin comprometer tu privacidad.",
    },
    terms: {
      title: "Términos de uso",
      body:
        "Las herramientas de CalculaTools están diseñadas para uso general y educativo. Los resultados son aproximados y pueden variar. Al usar el sitio aceptas utilizar las herramientas de manera responsable. Continuamos mejorando el proyecto para ofrecerte la mejor experiencia posible.",
    },
  };

  function openInfoOverlay(type) {
    if (!infoOverlay || !infoOverlayTitle || !infoOverlayBody) return;
    const content = infoContent[type];
    if (!content) return;

    infoOverlayTitle.textContent = content.title;
    infoOverlayBody.innerHTML = content.body.replace(/\n/g, "<br>");
    infoOverlay.classList.remove("hidden");
  }

  function closeInfoOverlay() {
    if (infoOverlay) infoOverlay.classList.add("hidden");
  }

  infoLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const type = link.getAttribute("data-info");
      openInfoOverlay(type);
    });
  });

  if (infoOverlayClose) {
    infoOverlayClose.addEventListener("click", () => {
      closeInfoOverlay();
    });
  }

  if (infoOverlay) {
    infoOverlay.addEventListener("click", (e) => {
      if (e.target === infoOverlay) {
        closeInfoOverlay();
      }
    });
  }

  /* ========= MODAL CALCULADORA DE IMC ========= */

  const imcOverlay = document.getElementById("imc-overlay");
  const imcCloseBtn = document.querySelector(".imc-close");
  const imcForm = document.getElementById("imc-form");
  const imcError = document.getElementById("imc-error");
  const imcResult = document.getElementById("imc-result");
  const imcValue = document.getElementById("imc-value");
  const imcCategory = document.getElementById("imc-category");
  const imcCard = document.querySelector('[data-tool="imc"]');

  function openImcOverlay() {
    if (imcOverlay) {
      imcOverlay.classList.remove("hidden");
      if (imcForm) imcForm.reset();
      if (imcError) imcError.classList.add("hidden");
      if (imcResult) imcResult.classList.add("hidden");
    }
  }

  function closeImcOverlay() {
    if (imcOverlay) {
      imcOverlay.classList.add("hidden");
    }
  }

  if (imcCard) {
    imcCard.style.cursor = "pointer";
    imcCard.addEventListener("click", () => {
      openImcOverlay();
    });
  }

  if (imcCloseBtn && imcOverlay) {
    imcCloseBtn.addEventListener("click", () => {
      closeImcOverlay();
    });

    imcOverlay.addEventListener("click", (e) => {
      if (e.target === imcOverlay) {
        closeImcOverlay();
      }
    });
  }

  if (imcForm && imcValue && imcCategory && imcError && imcResult) {
    imcForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const weightInput = document.getElementById("imc-weight");
      const heightInput = document.getElementById("imc-height");

      const weight = parseFloat(weightInput.value.replace(",", "."));
      const heightCm = parseFloat(heightInput.value.replace(",", "."));

      if (!weight || !heightCm || weight <= 0 || heightCm <= 0) {
        imcError.textContent = "Por favor ingresa un peso y una estatura válidos.";
        imcError.classList.remove("hidden");
        imcResult.classList.add("hidden");
        return;
      }

      imcError.classList.add("hidden");

      const heightM = heightCm / 100;
      const imc = weight / (heightM * heightM);
      const imcRounded = Math.round(imc * 10) / 10;

      let category = "";
      let extra = "";

      if (imc < 18.5) {
        category = "Bajo peso";
        extra =
          "Podrías revisar tus hábitos de alimentación y descanso 💛. Si lo ves necesario, consulta con un profesional de salud.";
      } else if (imc < 25) {
        category = "Rango saludable";
        extra =
          "Tu IMC está en un rango saludable ✨. Mantén tus buenos hábitos de alimentación y movimiento.";
      } else if (imc < 30) {
        category = "Sobrepeso";
        extra =
          "Tu IMC indica sobrepeso. Pequeños cambios en tu rutina pueden marcar una gran diferencia en el tiempo 💪.";
      } else {
        category = "Obesidad";
        extra =
          "Tu IMC está en rango de obesidad. Ser amable contigo y dar pasos poco a poco puede ayudarte mucho. Siempre es buena idea consultar con un profesional.";
      }

      imcValue.textContent = `Tu IMC es ${imcRounded.toFixed(1)}.`;
      imcCategory.textContent = `Categoría: ${category}. ${extra}`;
      imcResult.classList.remove("hidden");
    });
  }

  /* ========= MODAL CALCULADORA DE PRÉSTAMO ========= */

  const loanOverlay = document.getElementById("loan-overlay");
  const loanCloseBtn = document.querySelector(".loan-close");
  const loanForm = document.getElementById("loan-form");
  const loanError = document.getElementById("loan-error");
  const loanResult = document.getElementById("loan-result");
  const loanPayment = document.getElementById("loan-payment");
  const loanTotal = document.getElementById("loan-total");
  const loanInterest = document.getElementById("loan-interest");
  const loanCard = document.querySelector('[data-tool="loan"]');

  function openLoanOverlay() {
    if (loanOverlay) {
      loanOverlay.classList.remove("hidden");
      if (loanForm) loanForm.reset();
      if (loanError) loanError.classList.add("hidden");
      if (loanResult) loanResult.classList.add("hidden");
    }
  }

  function closeLoanOverlay() {
    if (loanOverlay) {
      loanOverlay.classList.add("hidden");
    }
  }

  if (loanCard) {
    loanCard.style.cursor = "pointer";
    loanCard.addEventListener("click", () => {
      openLoanOverlay();
    });
  }

  if (loanCloseBtn && loanOverlay) {
    loanCloseBtn.addEventListener("click", () => {
      closeLoanOverlay();
    });

    loanOverlay.addEventListener("click", (e) => {
      if (e.target === loanOverlay) {
        closeLoanOverlay();
      }
    });
  }

  if (loanForm && loanPayment && loanTotal && loanInterest && loanError && loanResult) {
    loanForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const amountInput = document.getElementById("loan-amount");
      const rateInput = document.getElementById("loan-rate");
      const monthsInput = document.getElementById("loan-months");

      const amount = parseFloat(amountInput.value.replace(",", "."));
      const rateYear = parseFloat(rateInput.value.replace(",", "."));
      const months = parseInt(monthsInput.value, 10);

      if (!amount || amount <= 0 || !months || months <= 0 || rateYear < 0) {
        loanError.textContent =
          "Por favor ingresa un monto, una tasa y un plazo válidos.";
        loanError.classList.remove("hidden");
        loanResult.classList.add("hidden");
        return;
      }

      loanError.classList.add("hidden");

      const monthlyRate = rateYear / 100 / 12;
      let payment;

      if (monthlyRate === 0) {
        payment = amount / months;
      } else {
        const factor = Math.pow(1 + monthlyRate, months);
        payment = (amount * monthlyRate * factor) / (factor - 1);
      }

      const totalPaid = payment * months;
      const totalInterest = totalPaid - amount;

      const format = (n) =>
        n.toLocaleString("es-PE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

      loanPayment.textContent = `Cuota mensual aproximada: ${format(payment)} (misma moneda del monto).`;
      loanTotal.textContent = `Total pagado al final del plazo: ${format(totalPaid)}.`;
      loanInterest.textContent = `Interés total aproximado: ${format(totalInterest)}.`;

      loanResult.classList.remove("hidden");
    });
  }

  /* ========= MODAL META DE AHORRO MENSUAL ========= */

  const savingOverlay = document.getElementById("saving-overlay");
  const savingCloseBtn = document.querySelector(".saving-close");
  const savingForm = document.getElementById("saving-form");
  const savingError = document.getElementById("saving-error");
  const savingResult = document.getElementById("saving-result");
  const savingMonthly = document.getElementById("saving-monthly");
  const savingWeekly = document.getElementById("saving-weekly");
  const savingDaily = document.getElementById("saving-daily");
  const savingCard = document.querySelector('[data-tool="saving"]');

  function openSavingOverlay() {
    if (savingOverlay) {
      savingOverlay.classList.remove("hidden");
      if (savingForm) savingForm.reset();
      if (savingError) savingError.classList.add("hidden");
      if (savingResult) savingResult.classList.add("hidden");
    }
  }

  function closeSavingOverlay() {
    if (savingOverlay) {
      savingOverlay.classList.add("hidden");
    }
  }

  if (savingCard) {
    savingCard.style.cursor = "pointer";
    savingCard.addEventListener("click", () => {
      openSavingOverlay();
    });
  }

  if (savingCloseBtn && savingOverlay) {
    savingCloseBtn.addEventListener("click", () => {
      closeSavingOverlay();
    });

    savingOverlay.addEventListener("click", (e) => {
      if (e.target === savingOverlay) {
        closeSavingOverlay();
      }
    });
  }

  if (
    savingForm &&
    savingError &&
    savingResult &&
    savingMonthly &&
    savingWeekly &&
    savingDaily
  ) {
    savingForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const goalInput = document.getElementById("saving-goal");
      const monthsInput = document.getElementById("saving-months");
      const initialInput = document.getElementById("saving-initial");

      const goal = parseFloat(goalInput.value.replace(",", "."));
      const months = parseInt(monthsInput.value, 10);
      let initial = 0;

      if (initialInput.value !== "") {
        initial = parseFloat(initialInput.value.replace(",", "."));
        if (isNaN(initial) || initial < 0) {
          initial = 0;
        }
      }

      if (!goal || goal <= 0 || !months || months <= 0) {
        savingError.textContent =
          "Por favor ingresa una meta y un plazo válidos.";
        savingError.classList.remove("hidden");
        savingResult.classList.add("hidden");
        return;
      }

      const remaining = goal - initial;

      if (remaining <= 0) {
        savingError.textContent =
          "Tu ahorro actual ya cubre o supera la meta. Puedes ajustar la meta o el ahorro inicial.";
        savingError.classList.remove("hidden");
        savingResult.classList.add("hidden");
        return;
      }

      savingError.classList.add("hidden");

      const monthly = remaining / months;
      // Aprox semanas y días en base al total
      const weeksApprox = months * 4;
      const daysApprox = months * 30;

      const weekly = remaining / weeksApprox;
      const daily = remaining / daysApprox;

      const format = (n) =>
        n.toLocaleString("es-PE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

      savingMonthly.textContent = `Ahorro mensual aproximado: ${format(
        monthly
      )} (misma moneda de la meta).`;
      savingWeekly.textContent = `Equivalente semanal orientativo: ${format(
        weekly
      )}.`;
      savingDaily.textContent = `Equivalente diario orientativo: ${format(
        daily
      )}.`;

      savingResult.classList.remove("hidden");
    });
  }

  /* ========= TECLA ESCAPE PARA CERRAR MODALES ========= */
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      closeInfoOverlay();
      closeImcOverlay();
      closeLoanOverlay();
      closeSavingOverlay();
    }
  });
});
/* ========= MODAL HORAS DE TRABAJO ========= */

const workOverlay = document.getElementById("work-overlay");
const workCloseBtn = document.querySelector(".work-close");
const workForm = document.getElementById("work-form");
const workError = document.getElementById("work-error");
const workResult = document.getElementById("work-result");
const workTotal = document.getElementById("work-total");
const workNet = document.getElementById("work-net");
const workCard = document.querySelector('[data-tool="work"]');

function openWorkOverlay() {
  if (workOverlay) {
    workOverlay.classList.remove("hidden");
    if (workForm) workForm.reset();
    if (workError) workError.classList.add("hidden");
    if (workResult) workResult.classList.add("hidden");
  }
}

function closeWorkOverlay() {
  if (workOverlay) {
    workOverlay.classList.add("hidden");
  }
}

if (workCard) {
  workCard.style.cursor = "pointer";
  workCard.addEventListener("click", () => {
    openWorkOverlay();
  });
}

if (workCloseBtn && workOverlay) {
  workCloseBtn.addEventListener("click", () => {
    closeWorkOverlay();
  });

  workOverlay.addEventListener("click", (e) => {
    if (e.target === workOverlay) {
      closeWorkOverlay();
    }
  });
}

if (workForm && workTotal && workNet && workError && workResult) {
  workForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const startInput = document.getElementById("work-start");
    const endInput = document.getElementById("work-end");
    const breakInput = document.getElementById("work-break");

    const start = startInput.value;
    const end = endInput.value;
    let breakMinutes = parseInt(breakInput.value, 10);

    if (!breakMinutes || breakMinutes < 0) breakMinutes = 0;

    if (!start || !end) {
      workError.textContent = "Completa ambas horas.";
      workError.classList.remove("hidden");
      workResult.classList.add("hidden");
      return;
    }

    // Convertimos a minutos totales
    const [sh, sm] = start.split(":").map(Number);
    const [eh, em] = end.split(":").map(Number);

    let startMinutes = sh * 60 + sm;
    let endMinutes = eh * 60 + em;

    if (endMinutes < startMinutes) {
      // turno que cruza medianoche
      endMinutes += 24 * 60;
    }

    const totalMinutes = endMinutes - startMinutes;

    if (totalMinutes <= 0) {
      workError.textContent = "Las horas ingresadas no son válidas.";
      workError.classList.remove("hidden");
      workResult.classList.add("hidden");
      return;
    }

    workError.classList.add("hidden");

    const netMinutes = totalMinutes - breakMinutes;
    if (netMinutes <= 0) {
      workError.textContent =
        "El descanso es mayor al tiempo trabajado.";
      workError.classList.remove("hidden");
      workResult.classList.add("hidden");
      return;
    }

    const totalHours = Math.floor(totalMinutes / 60);
    const totalMin = totalMinutes % 60;

    const netHours = Math.floor(netMinutes / 60);
    const netMin = netMinutes % 60;

    workTotal.textContent = `Total trabajado: ${totalHours}h ${String(
      totalMin
    ).padStart(2, "0")}m`;

    workNet.textContent = `Neto después del descanso: ${netHours}h ${String(
      netMin
    ).padStart(2, "0")}m`;

    workResult.classList.remove("hidden");
  });
}
/* ========= MODAL CALCULADORA BÁSICA ========= */

const basicOverlay = document.getElementById("basic-overlay");
const basicCloseBtn = document.querySelector(".basic-close");
const basicCard = document.querySelector('[data-tool="basic"]');
const basicDisplay = document.getElementById("basic-display");
const basicEquals = document.getElementById("basic-equals");
const basicClear = document.getElementById("basic-clear");
const numButtons = document.querySelectorAll("[data-val]");
const opButtons = document.querySelectorAll("[data-op]");

function openBasicOverlay() {
  if (basicOverlay) {
    basicOverlay.classList.remove("hidden");
    basicDisplay.value = "";
  }
}

function closeBasicOverlay() {
  if (basicOverlay) {
    basicOverlay.classList.add("hidden");
  }
}

if (basicCard) {
  basicCard.style.cursor = "pointer";
  basicCard.addEventListener("click", () => {
    openBasicOverlay();
  });
}

if (basicCloseBtn) {
  basicCloseBtn.addEventListener("click", () => {
    closeBasicOverlay();
  });
}

if (basicOverlay) {
  basicOverlay.addEventListener("click", (e) => {
    if (e.target === basicOverlay) {
      closeBasicOverlay();
    }
  });
}

// Números
numButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    basicDisplay.value += btn.dataset.val;
  });
});

// Operadores
opButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    basicDisplay.value += btn.dataset.op;
  });
});

// Igual
if (basicEquals) {
  basicEquals.addEventListener("click", () => {
    try {
      const result = eval(basicDisplay.value);
      basicDisplay.value = result ?? "";
    } catch {
      basicDisplay.value = "Error";
    }
  });
}

// Limpiar
if (basicClear) {
  basicClear.addEventListener("click", () => {
    basicDisplay.value = "";
  });
}
/* ========= MODAL CALCULADORA DE PORCENTAJE ========= */

const percentOverlay = document.getElementById("percent-overlay");
const percentCloseBtn = document.querySelector(".percent-close");
const percentForm = document.getElementById("percent-form");
const percentError = document.getElementById("percent-error");
const percentResult = document.getElementById("percent-result");
const percentAmount = document.getElementById("percent-amount");
const percentPlus = document.getElementById("percent-plus");
const percentMinus = document.getElementById("percent-minus");
const percentCard = document.querySelector('[data-tool="percent"]');

function openPercentOverlay() {
  if (percentOverlay) {
    percentOverlay.classList.remove("hidden");
    percentForm.reset();
    percentError.classList.add("hidden");
    percentResult.classList.add("hidden");
  }
}

function closePercentOverlay() {
  if (percentOverlay) {
    percentOverlay.classList.add("hidden");
  }
}

if (percentCard) {
  percentCard.style.cursor = "pointer";
  percentCard.addEventListener("click", () => {
    openPercentOverlay();
  });
}

if (percentCloseBtn && percentOverlay) {
  percentCloseBtn.addEventListener("click", closePercentOverlay);

  percentOverlay.addEventListener("click", (e) => {
    if (e.target === percentOverlay) closePercentOverlay();
  });
}

if (
  percentForm &&
  percentError &&
  percentResult &&
  percentAmount &&
  percentPlus &&
  percentMinus
) {
  percentForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const numInput = document.getElementById("percent-number");
    const valInput = document.getElementById("percent-value");

    const number = parseFloat(numInput.value.replace(",", "."));
    const percent = parseFloat(valInput.value.replace(",", "."));

    if (!number || !percent || number < 0) {
      percentError.textContent = "Ingresa datos válidos (número y porcentaje).";
      percentError.classList.remove("hidden");
      percentResult.classList.add("hidden");
      return;
    }

    percentError.classList.add("hidden");

    const amount = (number * percent) / 100;
    const plus = number + amount;
    const minus = number - amount;

    const format = (n) =>
      n.toLocaleString("es-PE", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });

    percentAmount.textContent = `${percent}% de ${format(number)} es ${format(
      amount
    )}.`;

    percentPlus.textContent = `Si sumas el ${percent}%: ${format(plus)}.`;

    percentMinus.textContent = `Si restas el ${percent}%: ${format(minus)}.`;

    percentResult.classList.remove("hidden");
  });
}

/* ========= MODAL CALORÍAS DIARIAS ========= */
const caloriesOverlay = document.getElementById("calories-overlay");
const caloriesCloseBtn = document.querySelector(".calories-close");
const caloriesCard = document.querySelector('[data-tool="calories"]');
const caloriesForm = document.getElementById("calories-form");
const caloriesError = document.getElementById("calories-error");
const caloriesResult = document.getElementById("calories-result");
const caloriesValue = document.getElementById("calories-value");

function openCaloriesOverlay() {
  if (!caloriesOverlay) return;
  caloriesOverlay.classList.remove("hidden");
  if (caloriesForm) caloriesForm.reset();
  if (caloriesError) caloriesError.classList.add("hidden");
  if (caloriesResult) caloriesResult.classList.add("hidden");
}

function closeCaloriesOverlay() {
  if (!caloriesOverlay) return;
  caloriesOverlay.classList.add("hidden");
}

if (caloriesCard) {
  caloriesCard.style.cursor = "pointer";
  caloriesCard.addEventListener("click", openCaloriesOverlay);
}

if (caloriesCloseBtn && caloriesOverlay) {
  caloriesCloseBtn.addEventListener("click", closeCaloriesOverlay);
  caloriesOverlay.addEventListener("click", (e) => {
    if (e.target === caloriesOverlay) closeCaloriesOverlay();
  });
}

if (caloriesForm && caloriesValue && caloriesError && caloriesResult) {
  caloriesForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const weight = parseFloat(
      document.getElementById("calories-weight").value.replace(",", ".")
    );
    const height = parseFloat(
      document.getElementById("calories-height").value.replace(",", ".")
    );
    const age = parseFloat(
      document.getElementById("calories-age").value.replace(",", ".")
    );
    const gender = document.getElementById("calories-gender").value;
    const activity = parseFloat(
      document.getElementById("calories-activity").value
    );

    if (!weight || !height || !age || !gender || !activity) {
      caloriesError.textContent =
        "Por favor completa todos los campos con valores válidos.";
      caloriesError.classList.remove("hidden");
      caloriesResult.classList.add("hidden");
      return;
    }

    caloriesError.classList.add("hidden");

    // Fórmula Mifflin–St Jeor
    let bmr;
    if (gender === "male") {
      bmr = 10 * weight + 6.25 * height - 5 * age + 5;
    } else {
      bmr = 10 * weight + 6.25 * height - 5 * age - 161;
    }

    const calories = Math.round(bmr * activity);
    caloriesValue.textContent = `Estimación aproximada: ${calories.toLocaleString(
      "es-PE"
    )} kcal al día.`;
    caloriesResult.classList.remove("hidden");
  });
}

/* ========= CALCULADORA DE DARDOS ========= */

const dartsOverlay = document.getElementById("darts-overlay");
const dartsCloseBtn = document.querySelector(".darts-close");
const dartsForm = document.getElementById("darts-form");
const dartsError = document.getElementById("darts-error");
const dartsResult = document.getElementById("darts-result");
const dartsTotal = document.getElementById("darts-total");
const dartsAverage = document.getElementById("darts-average");
const dartsCard = document.querySelector('[data-tool="darts"]');

function openDartsOverlay() {
  if (dartsOverlay) {
    dartsOverlay.classList.remove("hidden");
    if (dartsForm) dartsForm.reset();
    if (dartsError) dartsError.classList.add("hidden");
    if (dartsResult) dartsResult.classList.add("hidden");
  }
}

function closeDartsOverlay() {
  if (dartsOverlay) {
    dartsOverlay.classList.add("hidden");
  }
}

if (dartsCard) {
  dartsCard.style.cursor = "pointer";
  dartsCard.addEventListener("click", openDartsOverlay);
}

if (dartsCloseBtn && dartsOverlay) {
  dartsCloseBtn.addEventListener("click", closeDartsOverlay);
  dartsOverlay.addEventListener("click", (e) => {
    if (e.target === dartsOverlay) closeDartsOverlay();
  });
}

if (dartsForm && dartsTotal && dartsAverage && dartsError && dartsResult) {
  dartsForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const raw = document.getElementById("darts-scores").value;

    const parts = raw
      .split(/[\s,;\n]+/)
      .map((p) => p.trim())
      .filter((p) => p.length > 0);

    if (parts.length === 0) {
      dartsError.textContent = "Ingresa al menos un valor numérico.";
      dartsError.classList.remove("hidden");
      dartsResult.classList.add("hidden");
      return;
    }

    let sum = 0;
    let count = 0;
    for (const p of parts) {
      const n = parseFloat(p.replace(",", "."));
      if (!isNaN(n)) {
        sum += n;
        count++;
      }
    }

    if (count === 0) {
      dartsError.textContent = "No se encontraron números válidos.";
      dartsError.classList.remove("hidden");
      dartsResult.classList.add("hidden");
      return;
    }

    dartsError.classList.add("hidden");
    const avg = sum / count;

    dartsTotal.textContent = `Puntuación total: ${sum.toFixed(0)} puntos.`;
    dartsAverage.textContent = `Promedio por lanzamiento/ronda: ${avg.toFixed(1)} puntos.`;
    dartsResult.classList.remove("hidden");
  });
}

/* ========= CALCULADORA ACADÉMICA ========= */

const academicOverlay = document.getElementById("academic-overlay");
const academicCloseBtn = document.querySelector(".academic-close");
const academicCard = document.querySelector('[data-tool="academic"]');
const academicType = document.getElementById("academic-type");

const academicFormRegla3 = document.getElementById("academic-form-regla3");
const academicFormPromedio = document.getElementById("academic-form-promedio");
const academicFormVelocidad = document.getElementById("academic-form-velocidad");
const academicFormDensidad = document.getElementById("academic-form-densidad");

const academicError = document.getElementById("academic-error");
const academicResult = document.getElementById("academic-result");
const academicOutput = document.getElementById("academic-output");

function openAcademicOverlay() {
  if (academicOverlay) {
    academicOverlay.classList.remove("hidden");
    // limpiar formularios
    if (academicFormRegla3) academicFormRegla3.reset();
    if (academicFormPromedio) academicFormPromedio.reset();
    if (academicFormVelocidad) academicFormVelocidad.reset();
    if (academicFormDensidad) academicFormDensidad.reset();
    if (academicError) academicError.classList.add("hidden");
    if (academicResult) academicResult.classList.add("hidden");
  }
}

function closeAcademicOverlay() {
  if (academicOverlay) academicOverlay.classList.add("hidden");
}

if (academicCard) {
  academicCard.style.cursor = "pointer";
  academicCard.addEventListener("click", openAcademicOverlay);
}

if (academicCloseBtn && academicOverlay) {
  academicCloseBtn.addEventListener("click", closeAcademicOverlay);
  academicOverlay.addEventListener("click", (e) => {
    if (e.target === academicOverlay) closeAcademicOverlay();
  });
}

function showAcademicForm(type) {
  if (!academicFormRegla3) return;
  // ocultar todos
  academicFormRegla3.classList.add("hidden");
  academicFormPromedio.classList.add("hidden");
  academicFormVelocidad.classList.add("hidden");
  academicFormDensidad.classList.add("hidden");
  if (academicError) academicError.classList.add("hidden");
  if (academicResult) academicResult.classList.add("hidden");

  if (type === "regla3") academicFormRegla3.classList.remove("hidden");
  if (type === "promedio") academicFormPromedio.classList.remove("hidden");
  if (type === "velocidad") academicFormVelocidad.classList.remove("hidden");
  if (type === "densidad") academicFormDensidad.classList.remove("hidden");
}

if (academicType) {
  showAcademicForm(academicType.value);
  academicType.addEventListener("change", () => {
    showAcademicForm(academicType.value);
  });
}

function academicShowError(msg) {
  if (academicError) {
    academicError.textContent = msg;
    academicError.classList.remove("hidden");
  }
  if (academicResult) academicResult.classList.add("hidden");
}

function academicShowResult(msg) {
  if (academicError) academicError.classList.add("hidden");
  if (academicOutput) academicOutput.textContent = msg;
  if (academicResult) academicResult.classList.remove("hidden");
}

// Regla de 3
if (academicFormRegla3) {
  academicFormRegla3.addEventListener("submit", (e) => {
    e.preventDefault();
    const a = parseFloat(document.getElementById("regla3-a").value.replace(",", "."));
    const b = parseFloat(document.getElementById("regla3-b").value.replace(",", "."));
    const c = parseFloat(document.getElementById("regla3-c").value.replace(",", "."));

    if (!a || !b || !c) {
      academicShowError("Completa A, B y C con valores válidos.");
      return;
    }
    const x = (b * c) / a;
    academicShowResult(`Resultado: X ≈ ${x.toFixed(4)}`);
  });
}

// Promedio
if (academicFormPromedio) {
  academicFormPromedio.addEventListener("submit", (e) => {
    e.preventDefault();
    const raw = document.getElementById("promedio-values").value;
    const parts = raw
      .split(/[\s,;\n]+/)
      .map((p) => p.trim())
      .filter((p) => p.length > 0);

    if (parts.length === 0) {
      academicShowError("Ingresa al menos un valor numérico.");
      return;
    }

    let sum = 0;
    let count = 0;
    for (const p of parts) {
      const n = parseFloat(p.replace(",", "."));
      if (!isNaN(n)) {
        sum += n;
        count++;
      }
    }

    if (count === 0) {
      academicShowError("No se encontraron números válidos.");
      return;
    }

    const avg = sum / count;
    academicShowResult(`Promedio ≈ ${avg.toFixed(2)}`);
  });
}

// Velocidad
if (academicFormVelocidad) {
  academicFormVelocidad.addEventListener("submit", (e) => {
    e.preventDefault();
    const d = parseFloat(
      document.getElementById("velocidad-distancia").value.replace(",", ".")
    );
    const t = parseFloat(
      document.getElementById("velocidad-tiempo").value.replace(",", ".")
    );

    if (!d || !t || t <= 0) {
      academicShowError("Ingresa una distancia y tiempo válidos (tiempo > 0).");
      return;
    }

    const v = d / t;
    academicShowResult(`Velocidad ≈ ${v.toFixed(3)} m/s`);
  });
}

// Densidad
if (academicFormDensidad) {
  academicFormDensidad.addEventListener("submit", (e) => {
    e.preventDefault();
    const m = parseFloat(
      document.getElementById("densidad-masa").value.replace(",", ".")
    );
    const v = parseFloat(
      document.getElementById("densidad-volumen").value.replace(",", ".")
    );

    if (!m || !v || v <= 0) {
      academicShowError("Ingresa masa y volumen válidos (volumen > 0).");
      return;
    }

    const d = m / v;
    academicShowResult(`Densidad ≈ ${d.toFixed(4)} g/cm³`);
  });
}

/* ========= CALCULADORA CIENTÍFICA ========= */

const scientificOverlay = document.getElementById("scientific-overlay");
const scientificCloseBtn = document.querySelector(".scientific-close");
const scientificCard = document.querySelector('[data-tool="scientific"]');
const scientificDisplay = document.getElementById("scientific-display");
const scientificError = document.getElementById("scientific-error");
const scientificButtons = document.querySelectorAll(".sci-btn");
const scientificFuncButtons = document.querySelectorAll(".sci-func");
const scientificClear = document.getElementById("scientific-clear");
const scientificEquals = document.getElementById("scientific-equals");

function openScientificOverlay() {
  if (scientificOverlay) {
    scientificOverlay.classList.remove("hidden");
    if (scientificDisplay) scientificDisplay.value = "";
    if (scientificError) scientificError.classList.add("hidden");
  }
}

function closeScientificOverlay() {
  if (scientificOverlay) scientificOverlay.classList.add("hidden");
}

if (scientificCard) {
  scientificCard.style.cursor = "pointer";
  scientificCard.addEventListener("click", openScientificOverlay);
}

if (scientificCloseBtn && scientificOverlay) {
  scientificCloseBtn.addEventListener("click", closeScientificOverlay);
  scientificOverlay.addEventListener("click", (e) => {
    if (e.target === scientificOverlay) closeScientificOverlay();
  });
}

function sciAppend(text) {
  if (!scientificDisplay) return;
  scientificDisplay.value += text;
}

if (scientificButtons && scientificDisplay) {
  scientificButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const val = btn.dataset.val;
      const op = btn.dataset.op;

      if (val) {
        sciAppend(val);
      } else if (op) {
        // operadores básicos
        sciAppend(op);
      }
    });
  });
}

if (scientificFuncButtons && scientificDisplay) {
  scientificFuncButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const func = btn.dataset.func;
      if (!func) return;

      if (func === "sqrt") {
        sciAppend("sqrt(");
      } else if (func === "sin") {
        sciAppend("sin(");
      } else if (func === "cos") {
        sciAppend("cos(");
      } else if (func === "tan") {
        sciAppend("tan(");
      } else if (func === "log") {
        sciAppend("log(");
      }
    });
  });
}

if (scientificClear && scientificDisplay) {
  scientificClear.addEventListener("click", () => {
    scientificDisplay.value = "";
    if (scientificError) scientificError.classList.add("hidden");
  });
}

function sciEvaluateExpression(expr) {
  // Reemplazos para usar Math.*
  let safe = expr;

  safe = safe.replace(/π/g, "Math.PI");
  safe = safe.replace(/sqrt\(/g, "Math.sqrt(");
  safe = safe.replace(/sin\(/g, "Math.sin(");
  safe = safe.replace(/cos\(/g, "Math.cos(");
  safe = safe.replace(/tan\(/g, "Math.tan(");
  safe = safe.replace(/log\(/g, "Math.log10(");

  // Potencia
  safe = safe.replace(/\^/g, "**");

  // Solo evalúa si contiene caracteres permitidos
  if (!/^[0-9+\-*/().,\s^MathPIlogintacqrs]*$/.test(safe)) {
    throw new Error("Expresión no válida.");
  }

  // eval controlado
  // eslint-disable-next-line no-eval
  const result = eval(safe);
  return result;
}

if (scientificEquals && scientificDisplay) {
  scientificEquals.addEventListener("click", () => {
    if (!scientificDisplay.value.trim()) return;

    try {
      const expr = scientificDisplay.value.replace(",", ".");
      const res = sciEvaluateExpression(expr);

      if (typeof res === "number" && isFinite(res)) {
        scientificDisplay.value = String(res);
        if (scientificError) scientificError.classList.add("hidden");
      } else {
        throw new Error("Resultado no válido.");
      }
    } catch (err) {
      if (scientificError) {
        scientificError.textContent =
          "No pudimos interpretar la operación. Revisa los paréntesis y la expresión.";
        scientificError.classList.remove("hidden");
      }
    }
  });
}

/* ========= MODAL CONVERTIDOR DE MONEDA ========= */

const currencyOverlay = document.getElementById("currency-overlay");
const currencyCloseBtn = document.querySelector(".currency-close");
const currencyForm = document.getElementById("currency-form");
const currencyError = document.getElementById("currency-error");
const currencyResult = document.getElementById("currency-result");
const currencyOutput = document.getElementById("currency-output");
const currencyNote = document.getElementById("currency-note");
const currencyCard = document.querySelector('[data-tool="currency"]');

// Tasas aproximadas para ejemplo
const currencyRates = {
  PEN: 1,
  USD: 3.8,
  EUR: 4.1,
  MXN: 0.22
};

function openCurrencyOverlay() {
  if (currencyOverlay) {
    currencyOverlay.classList.remove("hidden");
    currencyForm.reset();
    currencyError.classList.add("hidden");
    currencyResult.classList.add("hidden");
  }
}

function closeCurrencyOverlay() {
  if (currencyOverlay) {
    currencyOverlay.classList.add("hidden");
  }
}

if (currencyCard) {
  currencyCard.style.cursor = "pointer";
  currencyCard.addEventListener("click", () => {
    openCurrencyOverlay();
  });
}

if (currencyCloseBtn) {
  currencyCloseBtn.addEventListener("click", closeCurrencyOverlay);
}

if (currencyOverlay) {
  currencyOverlay.addEventListener("click", (e) => {
    if (e.target === currencyOverlay) closeCurrencyOverlay();
  });
}

if (currencyForm) {
  currencyForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const amountInput = document.getElementById("currency-amount");
    const fromSelect = document.getElementById("currency-from");
    const toSelect = document.getElementById("currency-to");

    const amount = parseFloat(amountInput.value.replace(",", "."));
    const from = fromSelect.value;
    const to = toSelect.value;

    if (!amount || amount <= 0) {
      currencyError.textContent = "Ingresa un monto válido mayor que cero.";
      currencyError.classList.remove("hidden");
      currencyResult.classList.add("hidden");
      return;
    }

    if (from === to) {
      currencyError.textContent = "Selecciona monedas diferentes.";
      currencyError.classList.remove("hidden");
      currencyResult.classList.add("hidden");
      return;
    }

    const rateFrom = currencyRates[from];
    const rateTo = currencyRates[to];

    if (!rateFrom || !rateTo) {
      currencyError.textContent = "No se pudo obtener la conversión.";
      currencyError.classList.remove("hidden");
      currencyResult.classList.add("hidden");
      return;
    }

    currencyError.classList.add("hidden");

    const converted = (amount * rateFrom) / rateTo;

    const format = (n, code) =>
      n.toLocaleString("es-PE", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }) + ` ${code}`;

    currencyOutput.textContent = `${format(amount, from)} ≈ ${format(converted, to)}.`;
    currencyNote.textContent = "Tasas aproximadas, no en tiempo real.";

    currencyResult.classList.remove("hidden");
  });
}
// ========= MODAL CONVERTIDOR DE PESO =========
(function () {
  const weightOverlay = document.getElementById("weight-overlay");
  const weightCloseBtn = document.querySelector(".weight-close");
  const weightForm = document.getElementById("weight-form");
  const weightError = document.getElementById("weight-error");
  const weightResult = document.getElementById("weight-result");
  const weightOutput = document.getElementById("weight-output");
  const weightNote = document.getElementById("weight-note");
  const weightCard = document.querySelector('[data-tool="weight"]');

  // factores en relación a 1 kilogramo
  const weightFactors = {
    kg: 1,
    g: 0.001,
    lb: 0.45359237,
    oz: 0.0283495231
  };

  function openWeightOverlay() {
    if (weightOverlay && weightForm && weightError && weightResult) {
      weightOverlay.classList.remove("hidden");
      weightForm.reset();
      weightError.classList.add("hidden");
      weightResult.classList.add("hidden");
    }
  }

  function closeWeightOverlay() {
    if (weightOverlay) {
      weightOverlay.classList.add("hidden");
    }
  }

  // abrir al hacer clic en la tarjeta de Peso
  if (weightCard) {
    weightCard.style.cursor = "pointer";
    weightCard.addEventListener("click", openWeightOverlay);
  }

  // cerrar con la X
  if (weightCloseBtn) {
    weightCloseBtn.addEventListener("click", closeWeightOverlay);
  }

  // cerrar haciendo clic fuera del cuadro
  if (weightOverlay) {
    weightOverlay.addEventListener("click", (e) => {
      if (e.target === weightOverlay) closeWeightOverlay();
    });
  }

  // conversión
  if (
    weightForm &&
    weightError &&
    weightResult &&
    weightOutput &&
    weightNote
  ) {
    weightForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const amountInput = document.getElementById("weight-amount");
      const fromSelect = document.getElementById("weight-from");
      const toSelect = document.getElementById("weight-to");

      const amount = parseFloat(
        (amountInput.value || "").toString().replace(",", ".")
      );
      const from = fromSelect.value;
      const to = toSelect.value;

      if (!amount || amount <= 0) {
        weightError.textContent = "Ingresa una cantidad válida mayor que cero.";
        weightError.classList.remove("hidden");
        weightResult.classList.add("hidden");
        return;
      }

      if (from === to) {
        weightError.textContent = "Selecciona unidades diferentes para convertir.";
        weightError.classList.remove("hidden");
        weightResult.classList.add("hidden");
        return;
      }

      const factorFrom = weightFactors[from];
      const factorTo = weightFactors[to];

      if (!factorFrom || !factorTo) {
        weightError.textContent = "No se encontró la unidad seleccionada.";
        weightError.classList.remove("hidden");
        weightResult.classList.add("hidden");
        return;
      }

      weightError.classList.add("hidden");

      // todo pasa por kilogramos
      const inKg = amount * factorFrom;
      const converted = inKg / factorTo;

      const format = (n) =>
        n.toLocaleString("es-PE", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        });

      weightOutput.textContent = `${format(amount)} ${from} ≈ ${format(
        converted
      )} ${to}.`;

      weightNote.textContent =
        "Conversión aproximada entre unidades de peso.";

      weightResult.classList.remove("hidden");
    });
  }

  // cerrar con tecla ESC (extra, solo para peso)
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      closeWeightOverlay();
    }
  });
})();
// ========= MODAL CONVERTIDOR DE LONGITUD =========
(function () {
  const lengthOverlay = document.getElementById("length-overlay");
  const lengthCloseBtn = document.querySelector(".length-close");
  const lengthForm = document.getElementById("length-form");
  const lengthError = document.getElementById("length-error");
  const lengthResult = document.getElementById("length-result");
  const lengthOutput = document.getElementById("length-output");
  const lengthNote = document.getElementById("length-note");
  const lengthCard = document.querySelector('[data-tool="length"]');

  // factores en relación a 1 metro
  const lengthFactors = {
    m: 1,
    km: 1000,
    ft: 0.3048,
    in: 0.0254
  };

  function openLengthOverlay() {
    lengthOverlay.classList.remove("hidden");
    lengthForm.reset();
    lengthError.classList.add("hidden");
    lengthResult.classList.add("hidden");
  }

  function closeLengthOverlay() {
    lengthOverlay.classList.add("hidden");
  }

  if (lengthCard) {
    lengthCard.style.cursor = "pointer";
    lengthCard.addEventListener("click", openLengthOverlay);
  }

  if (lengthCloseBtn) {
    lengthCloseBtn.addEventListener("click", closeLengthOverlay);
  }

  if (lengthOverlay) {
    lengthOverlay.addEventListener("click", (e) => {
      if (e.target === lengthOverlay) closeLengthOverlay();
    });
  }

  if (lengthForm) {
    lengthForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const amountInput = document.getElementById("length-amount");
      const from = document.getElementById("length-from").value;
      const to = document.getElementById("length-to").value;

      const amount = parseFloat(
        (amountInput.value || "").toString().replace(",", ".")
      );

      if (!amount || amount <= 0) {
        lengthError.textContent = "Ingresa una cantidad válida mayor que cero.";
        lengthError.classList.remove("hidden");
        lengthResult.classList.add("hidden");
        return;
      }

      if (from === to) {
        lengthError.textContent = "Selecciona unidades diferentes para convertir.";
        lengthError.classList.remove("hidden");
        lengthResult.classList.add("hidden");
        return;
      }

      const factorFrom = lengthFactors[from];
      const factorTo = lengthFactors[to];

      const inMeters = amount * factorFrom;
      const converted = inMeters / factorTo;

      const format = (n) =>
        n.toLocaleString("es-PE", {
          minimumFractionDigits: 4,
          maximumFractionDigits: 4
        });

      lengthError.classList.add("hidden");

      lengthOutput.textContent = `${format(amount)} ${from} ≈ ${format(
        converted
      )} ${to}.`;
      lengthNote.textContent = "Conversión aproximada entre unidades de distancia.";

      lengthResult.classList.remove("hidden");
    });
  }

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeLengthOverlay();
  });
})();
// ========= MODAL CONVERTIDOR DE TEMPERATURA =========
(function () {
  const tempOverlay = document.getElementById("temperature-overlay");
  const tempCloseBtn = document.querySelector(".temperature-close");
  const tempForm = document.getElementById("temperature-form");
  const tempError = document.getElementById("temperature-error");
  const tempResult = document.getElementById("temperature-result");
  const tempOutput = document.getElementById("temperature-output");
  const tempNote = document.getElementById("temperature-note");
  const tempCard = document.querySelector('[data-tool="temperature"]');

  function openTempOverlay() {
    tempOverlay.classList.remove("hidden");
    tempForm.reset();
    tempError.classList.add("hidden");
    tempResult.classList.add("hidden");
  }

  function closeTempOverlay() {
    tempOverlay.classList.add("hidden");
  }

  if (tempCard) {
    tempCard.style.cursor = "pointer";
    tempCard.addEventListener("click", openTempOverlay);
  }

  if (tempCloseBtn) {
    tempCloseBtn.addEventListener("click", closeTempOverlay);
  }

  if (tempOverlay) {
    tempOverlay.addEventListener("click", (e) => {
      if (e.target === tempOverlay) closeTempOverlay();
    });
  }

  function convertTemperature(value, from, to) {
    if (from === "c" && to === "f") {
      return value * 9 / 5 + 32;
    }
    if (from === "f" && to === "c") {
      return (value - 32) * 5 / 9;
    }
    return value;
  }

  if (tempForm) {
    tempForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const amount = parseFloat(
        (document.getElementById("temperature-amount").value || "")
          .toString()
          .replace(",", ".")
      );

      const from = document.getElementById("temperature-from").value;
      const to = document.getElementById("temperature-to").value;

      if (isNaN(amount)) {
        tempError.textContent = "Ingresa una temperatura válida.";
        tempError.classList.remove("hidden");
        tempResult.classList.add("hidden");
        return;
      }

      if (from === to) {
        tempError.textContent = "Selecciona escalas diferentes.";
        tempError.classList.remove("hidden");
        tempResult.classList.add("hidden");
        return;
      }

      const converted = convertTemperature(amount, from, to);

      const format = (n) =>
        n.toLocaleString("es-PE", {
          minimumFractionDigits: 1,
          maximumFractionDigits: 1
        });

      tempError.classList.add("hidden");

      tempOutput.textContent = `${format(amount)}°${from.toUpperCase()} ≈ ${format(
        converted
      )}°${to.toUpperCase()}`;

      tempNote.textContent = "Conversión aproximada entre escalas de temperatura.";

      tempResult.classList.remove("hidden");
    });
  }

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeTempOverlay();
  });
})();

// ========= MODAL CONVERTIDOR DE VELOCIDAD =========
(function () {
  const speedOverlay = document.getElementById("speed-overlay");
  const speedCloseBtn = document.querySelector(".speed-close");
  const speedForm = document.getElementById("speed-form");
  const speedError = document.getElementById("speed-error");
  const speedResult = document.getElementById("speed-result");
  const speedOutput = document.getElementById("speed-output");
  const speedNote = document.getElementById("speed-note");
  const speedCard = document.querySelector('[data-tool="speed"]');

  // Factores en relación a 1 km/h
  const speedFactors = {
    kmh: 1,
    ms: 0.2777778,
    mph: 0.621371
  };

  function openSpeedOverlay() {
    speedOverlay.classList.remove("hidden");
    speedForm.reset();
    speedError.classList.add("hidden");
    speedResult.classList.add("hidden");
  }

  function closeSpeedOverlay() {
    speedOverlay.classList.add("hidden");
  }

  // abrir desde tarjeta
  if (speedCard) {
    speedCard.style.cursor = "pointer";
    speedCard.addEventListener("click", openSpeedOverlay);
  }

  // cerrar con X
  if (speedCloseBtn) {
    speedCloseBtn.addEventListener("click", closeSpeedOverlay);
  }

  // cerrar haciendo clic afuera
  if (speedOverlay) {
    speedOverlay.addEventListener("click", (e) => {
      if (e.target === speedOverlay) closeSpeedOverlay();
    });
  }

  // conversión
  if (speedForm) {
    speedForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const amount = parseFloat(
        (document.getElementById("speed-amount").value || "")
          .toString()
          .replace(",", ".")
      );

      const from = document.getElementById("speed-from").value;
      const to = document.getElementById("speed-to").value;

      if (!amount || amount <= 0) {
        speedError.textContent = "Ingresa un valor válido mayor que cero.";
        speedError.classList.remove("hidden");
        speedResult.classList.add("hidden");
        return;
      }

      if (from === to) {
        speedError.textContent = "Selecciona unidades diferentes.";
        speedError.classList.remove("hidden");
        speedResult.classList.add("hidden");
        return;
      }

      const factorFrom = speedFactors[from];
      const factorTo = speedFactors[to];

      const inKmh = amount * factorFrom;
      const converted = inKmh / factorTo;

      const format = (n) =>
        n.toLocaleString("es-PE", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        });

      speedError.classList.add("hidden");

      speedOutput.textContent = `${format(amount)} ${from} ≈ ${format(
        converted
      )} ${to}.`;

      speedNote.textContent = "Conversión aproximada entre unidades de velocidad.";

      speedResult.classList.remove("hidden");
    });
  }

  // cerrar con ESC
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeSpeedOverlay();
  });
})();
// ========= MODAL CONVERTIDOR DE VOLUMEN =========
(function () {
  const volumeOverlay = document.getElementById("volume-overlay");
  const volumeCloseBtn = document.querySelector(".volume-close");
  const volumeForm = document.getElementById("volume-form");
  const volumeError = document.getElementById("volume-error");
  const volumeResult = document.getElementById("volume-result");
  const volumeOutput = document.getElementById("volume-output");
  const volumeNote = document.getElementById("volume-note");
  const volumeCard = document.querySelector('[data-tool="volume"]');

  // factores en relación a 1 litro
  const volumeFactors = {
    l: 1,
    ml: 0.001,
    gal: 3.78541, // 1 galón ≈ 3.78541 L
    cup: 0.24    // 1 taza ≈ 0.24 L (aprox)
  };

  function openVolumeOverlay() {
    if (!volumeOverlay || !volumeForm || !volumeError || !volumeResult) return;
    volumeOverlay.classList.remove("hidden");
    volumeForm.reset();
    volumeError.classList.add("hidden");
    volumeResult.classList.add("hidden");
  }

  function closeVolumeOverlay() {
    if (!volumeOverlay) return;
    volumeOverlay.classList.add("hidden");
  }

  // abrir al hacer clic en la tarjeta
  if (volumeCard) {
    volumeCard.style.cursor = "pointer";
    volumeCard.addEventListener("click", openVolumeOverlay);
  }

  // cerrar con la X
  if (volumeCloseBtn) {
    volumeCloseBtn.addEventListener("click", closeVolumeOverlay);
  }

  // cerrar haciendo clic fuera del cuadro
  if (volumeOverlay) {
    volumeOverlay.addEventListener("click", (e) => {
      if (e.target === volumeOverlay) closeVolumeOverlay();
    });
  }

  // envío del formulario
  if (volumeForm && volumeError && volumeResult && volumeOutput && volumeNote) {
    volumeForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const amountInput = document.getElementById("volume-amount");
      const fromSelect = document.getElementById("volume-from");
      const toSelect = document.getElementById("volume-to");

      const amount = parseFloat(
        (amountInput.value || "").toString().replace(",", ".")
      );
      const from = fromSelect.value;
      const to = toSelect.value;

      if (!amount || amount <= 0) {
        volumeError.textContent = "Ingresa una cantidad válida mayor que cero.";
        volumeError.classList.remove("hidden");
        volumeResult.classList.add("hidden");
        return;
      }

      if (from === to) {
        volumeError.textContent = "Selecciona unidades diferentes para convertir.";
        volumeError.classList.remove("hidden");
        volumeResult.classList.add("hidden");
        return;
      }

      const factorFrom = volumeFactors[from];
      const factorTo = volumeFactors[to];

      if (!factorFrom || !factorTo) {
        volumeError.textContent = "No se encontró la unidad seleccionada.";
        volumeError.classList.remove("hidden");
        volumeResult.classList.add("hidden");
        return;
      }

      volumeError.classList.add("hidden");

      // todo pasa por litros
      const inLiters = amount * factorFrom;
      const converted = inLiters / factorTo;

      const format = (n) =>
        n.toLocaleString("es-PE", {
          minimumFractionDigits: 3,
          maximumFractionDigits: 3
        });

      volumeOutput.textContent = `${format(amount)} ${from} ≈ ${format(
        converted
      )} ${to}.`;

      volumeNote.textContent = "Conversión aproximada entre unidades de volumen.";

      volumeResult.classList.remove("hidden");
    });
  }

  // cerrar con tecla ESC
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeVolumeOverlay();
  });
})();
/* ================================
   CONTADOR DE PALABRAS
================================== */

// Abrir overlay
document.querySelector('[data-tool="text-counter"]')
  .addEventListener('click', () => {
    document.getElementById('text-counter-overlay').classList.remove('hidden');
  });

// Cerrar overlay
document.querySelector('.text-counter-close')
  .addEventListener('click', () => {
    document.getElementById('text-counter-overlay').classList.add('hidden');
  });

// Botón de contar
document.getElementById('text-counter-btn')
  .addEventListener('click', () => {
    const text = document.getElementById('text-counter-input').value.trim();

    const errorBox = document.getElementById('text-counter-error');
    const resultBox = document.getElementById('text-counter-result');

    if (!text) {
      errorBox.textContent = "Por favor ingresa un texto.";
      errorBox.classList.remove('hidden');
      resultBox.classList.add('hidden');
      return;
    }

    errorBox.classList.add('hidden');

    // Cálculos
    const words = text.split(/\s+/).filter(w => w.length > 0).length;
    const chars = text.length;
    const lines = text.split(/\n/).length;

    // Mostrar resultados
    document.getElementById('text-counter-words').textContent =
      `Palabras: ${words}`;
    document.getElementById('text-counter-chars').textContent =
      `Caracteres: ${chars}`;
    document.getElementById('text-counter-lines').textContent =
      `Líneas: ${lines}`;

    resultBox.classList.remove('hidden');
  });
/* ================================
   MAYÚSCULAS / MINÚSCULAS
================================== */

// Abrir overlay
document.querySelector('[data-tool="text-case"]')
  .addEventListener('click', () => {
    document.getElementById('text-case-overlay').classList.remove('hidden');
  });

// Cerrar overlay
document.querySelector('.text-case-close')
  .addEventListener('click', () => {
    document.getElementById('text-case-overlay').classList.add('hidden');
  });

// Funciones de conversión
const caseInput = document.getElementById('text-case-input');
const caseOutput = document.getElementById('text-case-output');
const caseError = document.getElementById('text-case-error');
const caseResult = document.getElementById('text-case-result');

// Botones
document.querySelectorAll('.text-case-buttons button')
  .forEach(btn => {
    btn.addEventListener('click', () => {
      const mode = btn.dataset.case;
      let text = caseInput.value.trim();

      if (!text) {
        caseError.textContent = "Por favor ingresa un texto.";
        caseError.classList.remove('hidden');
        caseResult.classList.add('hidden');
        return;
      }

      caseError.classList.add('hidden');

      if (mode === "upper") {
        text = text.toUpperCase();
      } 
      else if (mode === "lower") {
        text = text.toLowerCase();
      }
      else if (mode === "title") {
        text = text.replace(/\w\S*/g, w =>
          w.charAt(0).toUpperCase() + w.substring(1).toLowerCase()
        );
      }

      caseOutput.textContent = text;
      caseResult.classList.remove('hidden');
    });
  });
/* ================================
   LIMPIAR TEXTO
================================== */

// Abrir overlay
document.querySelector('[data-tool="text-clean"]')
  .addEventListener('click', () => {
    document.getElementById('text-clean-overlay').classList.remove('hidden');
  });

// Cerrar
document.querySelector('.text-clean-close')
  .addEventListener('click', () => {
    document.getElementById('text-clean-overlay').classList.add('hidden');
  });

// Función de limpieza
document.getElementById('text-clean-btn')
  .addEventListener('click', () => {
    const text = document.getElementById('text-clean-input').value.trim();

    const errorBox = document.getElementById('text-clean-error');
    const resultBox = document.getElementById('text-clean-result');

    if (!text) {
      errorBox.textContent = "Por favor ingresa un texto.";
      errorBox.classList.remove('hidden');
      resultBox.classList.add('hidden');
      return;
    }

    errorBox.classList.add('hidden');

    // Limpieza:
    let cleaned = text;

    // Quitar espacios dobles
    cleaned = cleaned.replace(/\s\s+/g, ' ');

    // Quitar saltos de línea extra
    cleaned = cleaned.replace(/\n\s*\n+/g, '\n');

    // Quitar espacios al inicio y final de cada línea
    cleaned = cleaned.replace(/^[ \t]+|[ \t]+$/gm, '');

    document.getElementById('text-clean-output').textContent = cleaned;
    resultBox.classList.remove('hidden');
  });/* ================================
   TEXTO DE PRUEBA (LOREM IPSUM)
================================== */

const loremWords = `
lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum
`.trim().split(" ");

// Abrir overlay
document.querySelector('[data-tool="text-lorem"]')
  .addEventListener('click', () => {
    document.getElementById('text-lorem-overlay').classList.remove('hidden');
  });

// Cerrar overlay
document.querySelector('.text-lorem-close')
  .addEventListener('click', () => {
    document.getElementById('text-lorem-overlay').classList.add('hidden');
  });

// Generar texto
document.getElementById('text-lorem-btn')
  .addEventListener('click', () => {
    const count = parseInt(document.getElementById('text-lorem-length').value);
    const errorBox = document.getElementById('text-lorem-error');
    const resultBox = document.getElementById('text-lorem-result');

    if (!count || count < 5 || count > 500) {
      errorBox.textContent = "Ingrese un número entre 5 y 500 palabras.";
      errorBox.classList.remove('hidden');
      resultBox.classList.add('hidden');
      return;
    }

    errorBox.classList.add('hidden');

    let output = [];

    for (let i = 0; i < count; i++) {
      output.push(loremWords[i % loremWords.length]);
    }

    const finalText = output.join(" ") + ".";

    document.getElementById('text-lorem-output').textContent = finalText;
    resultBox.classList.remove('hidden');
  });

/* ================================
   CONTADOR DE LÍNEAS
================================== */

// Abrir overlay
document.querySelector('[data-tool="text-lines"]')
  .addEventListener('click', () => {
    document.getElementById('text-lines-overlay').classList.remove('hidden');
  });

// Cerrar overlay
document.querySelector('.text-lines-close')
  .addEventListener('click', () => {
    document.getElementById('text-lines-overlay').classList.add('hidden');
  });

// Contar líneas
document.getElementById('text-lines-btn')
  .addEventListener('click', () => {
    const text = document.getElementById('text-lines-input').value;

    const errorBox = document.getElementById('text-lines-error');
    const resultBox = document.getElementById('text-lines-result');

    if (!text.trim()) {
      errorBox.textContent = "Por favor ingresa un texto.";
      errorBox.classList.remove('hidden');
      resultBox.classList.add('hidden');
      return;
    }

    errorBox.classList.add('hidden');

    // Contar líneas
    const lines = text.split(/\n/).length;

    document.getElementById('text-lines-output').textContent =
      `Número de líneas: ${lines}`;

    resultBox.classList.remove('hidden');
  });
/* ================================
   QUITAR ACENTOS
================================== */

// Abrir overlay
document.querySelector('[data-tool="text-accents"]')
  .addEventListener('click', () => {
    document.getElementById('text-accents-overlay').classList.remove('hidden');
  });

// Cerrar overlay
document.querySelector('.text-accents-close')
  .addEventListener('click', () => {
    document.getElementById('text-accents-overlay').classList.add('hidden');
  });

// Función para quitar acentos
document.getElementById('text-accents-btn')
  .addEventListener('click', () => {
    const text = document.getElementById('text-accents-input').value.trim();

    const errorBox = document.getElementById('text-accents-error');
    const resultBox = document.getElementById('text-accents-result');

    if (!text) {
      errorBox.textContent = "Por favor ingresa un texto.";
      errorBox.classList.remove('hidden');
      resultBox.classList.add('hidden');
      return;
    }

    errorBox.classList.add('hidden');

    // Quitamos acentos
    const cleaned = text.normalize("NFD").replace(/[\u0300-\u036f]/g, "");

    document.getElementById('text-accents-output').textContent = cleaned;
    resultBox.classList.remove('hidden');
  });
/* ================================
   TEST: HÁBITOS DE ESTUDIO
================================== */

// Abrir overlay
document.querySelector('[data-tool="test-study"]')
  .addEventListener('click', () => {
    document.getElementById('test-study-overlay').classList.remove('hidden');
  });

// Cerrar overlay
document.querySelector('.test-study-close')
  .addEventListener('click', () => {
    document.getElementById('test-study-overlay').classList.add('hidden');
  });

// Lógica del test
document.getElementById('test-study-form')
  .addEventListener('submit', (e) => {
    e.preventDefault();

    const errorBox = document.getElementById('test-study-error');
    const resultBox = document.getElementById('test-study-result');
    const profileText = document.getElementById('test-study-profile');
    const tipsText = document.getElementById('test-study-tips');

    let score = 0;
    let valid = true;

    // Leer respuestas
    for (let i = 1; i <= 5; i++) {
      const answer = document.querySelector(`input[name="q${i}"]:checked`);
      if (!answer) {
        valid = false;
        break;
      }
      score += parseInt(answer.value);
    }

    if (!valid) {
      errorBox.textContent = "Por favor responde todas las preguntas.";
      errorBox.classList.remove('hidden');
      resultBox.classList.add('hidden');
      return;
    }

    errorBox.classList.add('hidden');

    // Perfiles
    if (score >= 8) {
      profileText.textContent = "📚 Perfil: Estudiante organizado · ¡Lo estás haciendo muy bien!";
      tipsText.textContent = "Consejo: Mantén tus horarios, repasa un poco cada día y sigue tu ritmo.";
    } 
    else if (score >= 4) {
      profileText.textContent = "✨ Perfil: Buen camino · Solo necesitas un poco más de constancia.";
      tipsText.textContent = "Consejo: Usa listas diarias y revisa 10 minutos tus apuntes.";
    } 
    else {
      profileText.textContent = "⏰ Perfil: Estudias a última hora, pero puedes mejorar paso a paso.";
      tipsText.textContent = "Consejo: Prueba la técnica pomodoro y estudia 15 minutos al día.";
    }

    resultBox.classList.remove('hidden');
  });
/* ================================
   TEST: HÁBITOS DE DINERO
================================== */

// Abrir
document.querySelector('[data-tool="test-money"]')
  .addEventListener('click', () => {
    document.getElementById('test-money-overlay').classList.remove('hidden');
  });

// Cerrar
document.querySelector('.test-money-close')
  .addEventListener('click', () => {
    document.getElementById('test-money-overlay').classList.add('hidden');
  });

// Lógica
document.getElementById('test-money-form')
  .addEventListener('submit', (e) => {
    e.preventDefault();

    const errorBox = document.getElementById('test-money-error');
    const resultBox = document.getElementById('test-money-result');
    const profileText = document.getElementById('test-money-profile');
    const tipsText = document.getElementById('test-money-tips');

    let score = 0;
    let valid = true;

    for (let i = 1; i <= 5; i++) {
      const ans = document.querySelector(`input[name="mq${i}"]:checked`);
      if (!ans) { valid = false; break; }
      score += parseInt(ans.value);
    }

    if (!valid) {
      errorBox.textContent = "Responde todas las preguntas.";
      errorBox.classList.remove("hidden");
      resultBox.classList.add("hidden");
      return;
    }

    errorBox.classList.add("hidden");

    // Perfiles
    if (score >= 8) {
      profileText.textContent = "💸 Perfil: Financiero responsable · ¡Muy buen manejo!";
      tipsText.textContent = "Sigue controlando tus gastos y mantén tus metas claras.";
    }
    else if (score >= 4) {
      profileText.textContent = "✨ Perfil: Intermedio · Puedes mejorar tu control.";
      tipsText.textContent = "Intenta anotar tus gastos semanales y ahorrar un poco más.";
    }
    else {
      profileText.textContent = "⚠️ Perfil: Gastador impulsivo · Pero puedes cambiarlo.";
      tipsText.textContent = "Evita compras rápidas y establece una meta de ahorro mensual.";
    }

    resultBox.classList.remove("hidden");
  });
/* ================================
   TEST: RUTINA DE SUEÑO
================================== */

// Abrir
document.querySelector('[data-tool="test-sleep"]')
  .addEventListener('click', () => {
    document.getElementById('test-sleep-overlay').classList.remove('hidden');
  });

// Cerrar
document.querySelector('.test-sleep-close')
  .addEventListener('click', () => {
    document.getElementById('test-sleep-overlay').classList.add('hidden');
  });

// Lógica
document.getElementById('test-sleep-form')
  .addEventListener('submit', (e) => {
    e.preventDefault();

    const errorBox = document.getElementById('test-sleep-error');
    const resultBox = document.getElementById('test-sleep-result');
    const profileText = document.getElementById('test-sleep-profile');
    const tipsText = document.getElementById('test-sleep-tips');

    let score = 0;
    let valid = true;

    for (let i = 1; i <= 5; i++) {
      const ans = document.querySelector(`input[name="sq${i}"]:checked`);
      if (!ans) { valid = false; break; }
      score += parseInt(ans.value);
    }

    if (!valid) {
      errorBox.textContent = "Por favor responde todas las preguntas.";
      errorBox.classList.remove("hidden");
      resultBox.classList.add("hidden");
      return;
    }

    errorBox.classList.add("hidden");

    // Perfiles motivadores
    if (score >= 8) {
      profileText.textContent = "😴 Perfil: Descanso bastante cuidado · ¡Muy bien!";
      tipsText.textContent = "Sigue cuidando tus horarios y tu ambiente de sueño. Mantener esa rutina te ayuda mucho.";
    } 
    else if (score >= 4) {
      profileText.textContent = "🌙 Perfil: Sueño irregular · Puedes mejorarlo poco a poco.";
      tipsText.textContent = "Prueba acostarte a horas más parecidas y bajar el uso del celular antes de dormir.";
    } 
    else {
      profileText.textContent = "⏰ Perfil: Sueño muy desordenado · Pero puedes comenzar con cambios pequeños.";
      tipsText.textContent = "Intenta fijar una hora para dormir y crea una rutina relajante antes de acostarte.";
    }

    resultBox.classList.remove("hidden");
  });
/* ================================
   TEST: ESTILO DE VIDA SALUDABLE
================================== */

// Abrir
document.querySelector('[data-tool="test-health"]')
  .addEventListener('click', () => {
    document.getElementById('test-health-overlay').classList.remove('hidden');
  });

// Cerrar
document.querySelector('.test-health-close')
  .addEventListener('click', () => {
    document.getElementById('test-health-overlay').classList.add('hidden');
  });

// Lógica
document.getElementById('test-health-form')
  .addEventListener('submit', (e) => {
    e.preventDefault();

    const errorBox = document.getElementById('test-health-error');
    const resultBox = document.getElementById('test-health-result');
    const profileText = document.getElementById('test-health-profile');
    const tipsText = document.getElementById('test-health-tips');

    let score = 0;
    let valid = true;

    for (let i = 1; i <= 5; i++) {
      const ans = document.querySelector(`input[name="hq${i}"]:checked`);
      if (!ans) { valid = false; break; }
      score += parseInt(ans.value);
    }

    if (!valid) {
      errorBox.textContent = "Por favor responde todas las preguntas.";
      errorBox.classList.remove("hidden");
      resultBox.classList.add("hidden");
      return;
    }

    errorBox.classList.add("hidden");

    // Perfiles positivos + motivadores
    if (score >= 8) {
      profileText.textContent = "🌿 Perfil: Muy saludable · ¡Excelente trabajo!";
      tipsText.textContent = "Sigue así. Tu constancia en comida, agua, sueño y movimiento se nota.";
    } 
    else if (score >= 4) {
      profileText.textContent = "🍃 Perfil: Moderadamente saludable · Vas por buen camino.";
      tipsText.textContent = "Pequeños hábitos como más agua o caminar 20 minutos diarios te ayudarán mucho.";
    } 
    else {
      profileText.textContent = "💛 Perfil: Estilo de vida mejorable · Puedes comenzar paso a paso.";
      tipsText.textContent = "Empieza con un cambio pequeño cada semana: más agua, más sueño o menos azúcar.";
    }

    resultBox.classList.remove("hidden");
  });
/* ================================
   TEST: GESTIÓN DEL TIEMPO
================================== */

// Abrir
document.querySelector('[data-tool="test-time"]')
  .addEventListener('click', () => {
    document.getElementById('test-time-overlay').classList.remove('hidden');
  });

// Cerrar
document.querySelector('.test-time-close')
  .addEventListener('click', () => {
    document.getElementById('test-time-overlay').classList.add('hidden');
  });

// Lógica
document.getElementById('test-time-form')
  .addEventListener('submit', (e) => {
    e.preventDefault();

    const errorBox = document.getElementById('test-time-error');
    const resultBox = document.getElementById('test-time-result');
    const profileText = document.getElementById('test-time-profile');
    const tipsText = document.getElementById('test-time-tips');

    let score = 0;
    let valid = true;

    for (let i = 1; i <= 5; i++) {
      const ans = document.querySelector(`input[name="tq${i}"]:checked`);
      if (!ans) { valid = false; break; }
      score += parseInt(ans.value);
    }

    if (!valid) {
      errorBox.textContent = "Por favor responde todas las preguntas.";
      errorBox.classList.remove("hidden");
      resultBox.classList.add("hidden");
      return;
    }

    errorBox.classList.add("hidden");

    // Perfiles motivadores
    if (score >= 8) {
      profileText.textContent = "⏱️ Perfil: Muy buen manejo del tiempo · ¡Felicitaciones!";
      tipsText.textContent = "Sigue planificando tus días y manteniendo momentos de descanso.";
    } 
    else if (score >= 4) {
      profileText.textContent = "📅 Perfil: Organización intermedia · Vas por buen camino.";
      tipsText.textContent = "Te ayudará usar una lista diaria y reducir distracciones en bloques de tiempo.";
    } 
    else {
      profileText.textContent = "🔥 Perfil: Modo ‘apaga incendios’ · pero puedes mejorar paso a paso.";
      tipsText.textContent = "Empieza por elegir 1 tarea importante al día y hacerla sin distracciones.";
    }

    resultBox.classList.remove("hidden");
  });
/* ================================
   TEST: USO DE REDES SOCIALES
================================== */

// Abrir
document.querySelector('[data-tool="test-social"]')
  .addEventListener('click', () => {
    document.getElementById('test-social-overlay').classList.remove('hidden');
  });

// Cerrar
document.querySelector('.test-social-close')
  .addEventListener('click', () => {
    document.getElementById('test-social-overlay').classList.add('hidden');
  });

// Lógica
document.getElementById('test-social-form')
  .addEventListener('submit', (e) => {
    e.preventDefault();

    const errorBox = document.getElementById('test-social-error');
    const resultBox = document.getElementById('test-social-result');
    const profileText = document.getElementById('test-social-profile');
    const tipsText = document.getElementById('test-social-tips');

    let score = 0;
    let valid = true;

    for (let i = 1; i <= 5; i++) {
      const ans = document.querySelector(`input[name="rq${i}"]:checked`);
      if (!ans) { valid = false; break; }
      score += parseInt(ans.value);
    }

    if (!valid) {
      errorBox.textContent = "Por favor responde todas las preguntas.";
      errorBox.classList.remove("hidden");
      resultBox.classList.add("hidden");
      return;
    }

    errorBox.classList.add("hidden");

    // Perfiles motivadores
    if (score >= 8) {
      profileText.textContent = "📱 Perfil: Uso bastante consciente · ¡Muy bien!";
      tipsText.textContent = "Sigue manteniendo momentos sin pantalla y priorizando tus actividades importantes.";
    } 
    else if (score >= 4) {
      profileText.textContent = "📲 Perfil: Uso moderado · Puedes equilibrarlo un poco más.";
      tipsText.textContent = "Prueba poner límites de tiempo diario y evitar redes antes de dormir.";
    } 
    else {
      profileText.textContent = "⚠️ Perfil: Uso elevado de redes · Puedes mejorarlo sin dejar de disfrutar.";
      tipsText.textContent = "Empieza con pequeños retos: menos notificaciones y pausas sin celular durante el día.";
    }

    resultBox.classList.remove("hidden");
  });
/* ================================
   INFO FOOTER: SOBRE / CONTACTO / PRIVACIDAD / TÉRMINOS
================================== */

function getFooterContent(type) {
  switch (type) {
    case 'about':
      return {
        title: 'Sobre CalculaTools',
        text: 'CalculaTools es un proyecto personal creado para ofrecerte calculadoras, convertidores y herramientas simples en un solo lugar. Buscamos que puedas hacer tus cuentas diarias de forma rápida, clara y cómoda, sin complicaciones.'
      };
    case 'contact':
      return {
        title: 'Contacto',
        text: 'Si tienes sugerencias, comentarios o encontraste algún detalle que podemos mejorar, puedes escribirnos a contacto@calculatools.com. Leemos cada mensaje con atención para seguir mejorando la página.'
      };
    case 'privacy':
      return {
        title: 'Privacidad',
        text: 'CalculaTools está pensada para usarse directamente en tu navegador. No pedimos registro ni contraseñas, y las herramientas están orientadas a que puedas hacer tus cálculos de forma tranquila. Aun así, te recomendamos no ingresar datos demasiado sensibles.'
      };
    case 'terms':
      return {
        title: 'Términos de uso',
        text: 'Las herramientas de CalculaTools se ofrecen como apoyo práctico para tu día a día. Procuramos que sean claras y útiles, y te invitamos a revisar siempre los resultados antes de tomar decisiones importantes. Nuestro objetivo es darte una experiencia sencilla, segura y agradable.'
      };
    default:
      return {
        title: 'Información',
        text: 'Sección informativa de CalculaTools.'
      };
  }
}

(function initFooterInfo() {
  const overlay = document.getElementById('footer-info-overlay');
  const titleEl = document.getElementById('footer-info-title');
  const textEl = document.getElementById('footer-info-text');
  const closeBtn = document.querySelector('.footer-info-close');
  const links = document.querySelectorAll('.footer-links a[data-info]');

  // Si falta algo, no hacemos nada (evitamos errores)
  if (!overlay || !titleEl || !textEl || !closeBtn || links.length === 0) {
    return;
  }

  // Abrir overlay según el link
  links.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const type = link.getAttribute('data-info');
      const content = getFooterContent(type);

      titleEl.textContent = content.title;
      textEl.textContent = content.text;

      overlay.classList.remove('hidden');
    });
  });

  // Cerrar con la X
  closeBtn.addEventListener('click', () => {
    overlay.classList.add('hidden');
  });

  // Cerrar haciendo clic fuera del cuadro
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) {
      overlay.classList.add('hidden');
    }
  });
})();
